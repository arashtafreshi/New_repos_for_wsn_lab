#ifndef TASK3_H
#define TASK3_H



typedef nx_struct BeaconMsg {
	nx_uint16_t BeaconSenderID;
}BeaconMsg_t;



enum {
 
	AM_BEACONMSG=2 ,
	
};
#endif /* TASK3_H */
